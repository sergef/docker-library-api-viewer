import BasePreset from "./base"

// Just the base, for now.

export default function PresetApis() {

  return [
    BasePreset,
  ]
}

When reporting an issue, please provide the following details:
- swagger-ui version
- a swagger file reproducing the issue
